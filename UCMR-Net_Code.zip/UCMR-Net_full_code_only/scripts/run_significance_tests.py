from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

import _bootstrap  # noqa: F401
from ucmr_net.utils.config import save_json


def paired_ttest(x, y):
    d = np.asarray(x) - np.asarray(y)
    n = len(d)
    mean = d.mean()
    sd = d.std(ddof=1) if n > 1 else 0.0
    if sd == 0 or n < 2:
        return {"t": float("inf") if mean != 0 else 0.0, "p_approx": 0.0 if mean != 0 else 1.0}
    t = mean / (sd / np.sqrt(n))
    # Normal approximation to two-sided p-value; suitable for automated reporting without scipy.
    import math
    p = 2 * (1 - 0.5 * (1 + math.erf(abs(t) / math.sqrt(2))))
    return {"t": float(t), "p_approx": float(p)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics-json", required=True, help="JSON created by run_unified_baselines.py")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--target-model", default="UCMR-Net")
    ap.add_argument("--compare", nargs="*", default=["BERT-only", "MAG-BERT", "CorrKD", "LNLN"])
    ap.add_argument("--metric", default="mae")
    args = ap.parse_args()
    data = json.loads(Path(args.metrics_json).read_text(encoding="utf-8"))
    target = [v[args.metric] for _, v in sorted(data[args.target_model].items())]
    results = {}
    for m in args.compare:
        vals = [v[args.metric] for _, v in sorted(data[m].items())]
        k = min(len(target), len(vals))
        results[f"{args.target_model}_vs_{m}_{args.metric}"] = paired_ttest(target[:k], vals[:k])
    save_json(results, Path(args.output_dir) / "significance_tests.json")


if __name__ == "__main__":
    main()
