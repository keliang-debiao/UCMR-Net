from __future__ import annotations

import argparse
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import train_one_seed, evaluate
from ucmr_net.utils.config import load_config, save_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--mosei-data", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--mode", choices=["train_test", "checkpoint_transfer"], default="train_test")
    ap.add_argument("--checkpoint", default=None, help="MOSI checkpoint for checkpoint_transfer mode")
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.mosei_data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    results = {}
    if args.mode == "checkpoint_transfer":
        if not args.checkpoint:
            raise ValueError("--checkpoint is required for checkpoint_transfer mode")
        model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
        ckpt = torch.load(args.checkpoint, map_location=device)
        model.load_state_dict(ckpt.get("state_dict", ckpt), strict=False)
        results["transfer"] = evaluate(model, loaders["test"], device)["metrics"]
    else:
        seeds = args.seeds or cfg.get("training", {}).get("seeds", [2026, 2027, 2028, 2029, 2030])
        for seed in seeds:
            model = build_ucmr_from_stats(stats, cfg.get("model", {}))
            res = train_one_seed(model, loaders, cfg, device, output_dir=str(Path(args.output_dir) / "mosei"), seed=seed)
            results[str(seed)] = res["metrics"]
    save_json(results, Path(args.output_dir) / "mosei_validation_metrics.json")


if __name__ == "__main__":
    main()
