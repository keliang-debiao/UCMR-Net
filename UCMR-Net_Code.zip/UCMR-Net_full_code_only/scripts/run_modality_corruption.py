from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import to_device
from ucmr_net.utils.metrics import all_metrics
from ucmr_net.utils.config import load_config, save_json


def corrupt(x: torch.Tensor, level: float) -> torch.Tensor:
    if level <= 0:
        return x
    noise = torch.randn_like(x) * x.std().clamp_min(1e-6) * level
    return x + noise


def eval_corruption(model, loader, device, modality: str, level: float):
    model.eval()
    labels, preds, weights = [], [], []
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, device)
            batch[modality] = corrupt(batch[modality], level)
            out = model(batch)
            labels.append(batch["label"].cpu().numpy())
            preds.append(out["regression"].cpu().numpy())
            if "residual_weights" in out:
                weights.append(out["residual_weights"].cpu().numpy())
    labels = np.concatenate(labels)
    preds = np.concatenate(preds)
    metrics = all_metrics(labels, preds)
    if weights:
        w = np.concatenate(weights)
        metrics["mean_audio_weight"] = float(w[:, 0].mean())
        metrics["mean_visual_weight"] = float(w[:, 1].mean())
    return metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--levels", nargs="*", type=float, default=[0.0, 0.2, 0.4, 0.6])
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt.get("state_dict", ckpt))
    results = {"audio": {}, "visual": {}}
    for level in args.levels:
        results["audio"][str(level)] = eval_corruption(model, loaders["test"], device, "audio", level)
        results["visual"][str(level)] = eval_corruption(model, loaders["test"], device, "visual", level)
    save_json(results, Path(args.output_dir) / "modality_corruption_metrics.json")


if __name__ == "__main__":
    main()
