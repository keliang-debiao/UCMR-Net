from __future__ import annotations

import argparse
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.data.multimodal_dataset import make_masked_batch, random_modality_mask
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import to_device
from ucmr_net.utils.metrics import all_metrics
from ucmr_net.utils.config import load_config, save_json


def eval_rate(model, loader, device, rate: float):
    model.eval()
    labels, preds = [], []
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, device)
            mask = random_modality_mask(batch["label"].size(0), rate, device)
            batch = make_masked_batch(batch, mask)
            out = model(batch)
            labels.append(batch["label"].cpu())
            preds.append(out["regression"].cpu())
    import numpy as np
    return all_metrics(torch.cat(labels).numpy(), torch.cat(preds).numpy())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--rates", nargs="*", type=float, default=[0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt.get("state_dict", ckpt))
    results = {str(r): eval_rate(model, loaders["test"], device, r) for r in args.rates}
    save_json(results, Path(args.output_dir) / "random_missing_metrics.json")


if __name__ == "__main__":
    main()
