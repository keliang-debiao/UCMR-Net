from __future__ import annotations

import argparse
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import train_one_seed
from ucmr_net.utils.config import load_config, save_json

VARIANTS = {
    "full_ucmr_net": {},
    "single_model_no_ensemble": {},
    "without_text_anchoring": {"text_anchor_mode": "mean"},
    "without_residual_fusion": {"use_residual_fusion": False},
    "without_adaptive_residual_weighting": {"use_adaptive_weighting": False},
    "without_counterfactual_distillation": {"distill": 0.0},
    "without_binary_polarity_supervision": {"binary": 0.0},
    "without_ordinal_supervision": {"ordinal": 0.0},
    "without_all_multitask_supervision": {"binary": 0.0, "ordinal": 0.0},
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    args = ap.parse_args()
    base_cfg = load_config(args.config)
    seeds = args.seeds or base_cfg.get("training", {}).get("seeds", [2026, 2027, 2028, 2029, 2030])
    loaders, stats = build_loaders(args.data, base_cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and base_cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    all_results = {}
    for variant, overrides in VARIANTS.items():
        all_results[variant] = {}
        variant_seeds = [seeds[0]] if variant == "single_model_no_ensemble" else seeds
        for seed in variant_seeds:
            cfg = {k: (v.copy() if isinstance(v, dict) else v) for k, v in base_cfg.items()}
            cfg["model"] = dict(base_cfg.get("model", {}))
            cfg["training"] = dict(base_cfg.get("training", {}))
            cfg["training"]["loss_weights"] = dict(base_cfg.get("training", {}).get("loss_weights", {}))
            for k, v in overrides.items():
                if k in {"text_anchor_mode", "use_residual_fusion", "use_adaptive_weighting"}:
                    cfg["model"][k] = v
                else:
                    cfg["training"]["loss_weights"][k] = v
                    if k == "distill":
                        for ph in cfg["training"].get("phases", []):
                            ph["distill"] = v
            model = build_ucmr_from_stats(stats, cfg.get("model", {}))
            res = train_one_seed(model, loaders, cfg, device, output_dir=str(Path(args.output_dir) / variant), seed=seed)
            all_results[variant][str(seed)] = res["metrics"]
    save_json(all_results, Path(args.output_dir) / "controlled_ablation_metrics.json")


if __name__ == "__main__":
    main()
