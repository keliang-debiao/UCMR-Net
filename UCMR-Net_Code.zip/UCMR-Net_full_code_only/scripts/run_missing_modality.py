from __future__ import annotations

import argparse
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import evaluate
from ucmr_net.utils.config import load_config, save_json

MASKS = {
    "complete": [1, 1, 1],
    "missing_text": [0, 1, 1],
    "missing_audio": [1, 0, 1],
    "missing_visual": [1, 1, 0],
    "text_only": [1, 0, 0],
    "audio_only": [0, 1, 0],
    "visual_only": [0, 0, 1],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt.get("state_dict", ckpt))
    results = {}
    for name, m in MASKS.items():
        mask = torch.tensor(m, dtype=torch.float32, device=device)
        results[name] = evaluate(model, loaders["test"], device, mask=mask)["metrics"]
    save_json(results, Path(args.output_dir) / "missing_modality_metrics.json")


if __name__ == "__main__":
    main()
