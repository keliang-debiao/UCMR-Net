from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import evaluate
from ucmr_net.utils.metrics import calibration_metrics, confidence_bins
from ucmr_net.utils.config import load_config, save_json


def fit_temperature(y_true, logits, grid=None):
    if grid is None:
        grid = np.linspace(0.5, 5.0, 91)
    best_t, best_nll = 1.0, float("inf")
    for t in grid:
        nll = calibration_metrics(y_true, logits / t)["nll"]
        if nll < best_nll:
            best_t, best_nll = float(t), float(nll)
    return best_t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt.get("state_dict", ckpt))
    val = evaluate(model, loaders["val"], device)
    test = evaluate(model, loaders["test"], device)
    t = fit_temperature(val["labels"], val["binary_logits"])
    raw = calibration_metrics(test["labels"], test["binary_logits"])
    scaled = calibration_metrics(test["labels"], test["binary_logits"] / t)
    bins = confidence_bins(test["labels"], test["binary_logits"] / t)
    save_json({"temperature": t, "raw": raw, "temperature_scaled": scaled, "bins": bins["bins"]}, Path(args.output_dir) / "calibration_metrics.json")


if __name__ == "__main__":
    main()
