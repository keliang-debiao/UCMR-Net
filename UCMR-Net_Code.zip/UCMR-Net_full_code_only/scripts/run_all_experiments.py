from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(cmd):
    print("[run]", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--mosi-data", required=True)
    ap.add_argument("--mosei-data", default=None)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    py = sys.executable
    run([py, "scripts/train_ucmr_net.py", "--config", args.config, "--data", args.mosi_data, "--output-dir", str(out / "ucmr")])
    ckpts = sorted((out / "ucmr" / "checkpoints").glob("ucmr_seed*.pt"))
    if ckpts:
        ckpt = str(ckpts[0])
        run([py, "scripts/run_missing_modality.py", "--config", args.config, "--data", args.mosi_data, "--checkpoint", ckpt, "--output-dir", str(out / "missing")])
        run([py, "scripts/run_random_missing.py", "--config", args.config, "--data", args.mosi_data, "--checkpoint", ckpt, "--output-dir", str(out / "random_missing")])
        run([py, "scripts/run_calibration.py", "--config", args.config, "--data", args.mosi_data, "--checkpoint", ckpt, "--output-dir", str(out / "calibration")])
        run([py, "scripts/run_reliability_error.py", "--config", args.config, "--data", args.mosi_data, "--checkpoint", ckpt, "--output-dir", str(out / "reliability")])
        run([py, "scripts/run_modality_corruption.py", "--config", args.config, "--data", args.mosi_data, "--checkpoint", ckpt, "--output-dir", str(out / "corruption")])
    run([py, "scripts/run_controlled_ablation.py", "--config", args.config, "--data", args.mosi_data, "--output-dir", str(out / "ablation")])
    run([py, "scripts/run_unified_baselines.py", "--config", args.config, "--data", args.mosi_data, "--output-dir", str(out / "baselines")])
    metrics = out / "baselines" / "unified_baseline_metrics.json"
    if metrics.exists():
        run([py, "scripts/run_significance_tests.py", "--metrics-json", str(metrics), "--output-dir", str(out / "significance")])
    if args.mosei_data:
        run([py, "scripts/run_mosei_validation.py", "--config", args.config, "--mosei-data", args.mosei_data, "--output-dir", str(out / "mosei")])


if __name__ == "__main__":
    main()
