from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import train_one_seed
from ucmr_net.utils.config import load_config, save_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True, help="NPZ file with train/val/test features and labels")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seeds = args.seeds or cfg.get("training", {}).get("seeds", [2026, 2027, 2028, 2029, 2030])
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), cfg.get("data", {}).get("num_workers", 0))
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    results = {}
    for seed in seeds:
        model = build_ucmr_from_stats(stats, cfg.get("model", {}))
        res = train_one_seed(model, loaders, cfg, device, output_dir=str(Path(args.output_dir) / "checkpoints"), seed=seed)
        results[str(seed)] = res["metrics"]
    save_json(results, Path(args.output_dir) / "metrics_by_seed.json")


if __name__ == "__main__":
    main()
