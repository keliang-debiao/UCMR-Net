from __future__ import annotations

import argparse
from pathlib import Path

import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.baselines import build_baseline
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import train_one_seed
from ucmr_net.utils.config import load_config, save_json

BASELINES = [
    "EF-LSTM", "LF-LSTM", "TFN", "LMF", "MulT", "MISA", "BERT-only",
    "MAG-BERT", "TFR-Net", "MissModal", "UMDF", "CorrKD", "LNLN", "UCMR-Net"
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--models", nargs="*", default=BASELINES)
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    seeds = args.seeds or cfg.get("training", {}).get("seeds", [2026, 2027, 2028, 2029, 2030])
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    results = {}
    for model_name in args.models:
        results[model_name] = {}
        for seed in seeds:
            if model_name.lower() == "ucmr-net":
                model = build_ucmr_from_stats(stats, cfg.get("model", {}))
            else:
                model = build_baseline(model_name, stats, cfg.get("baseline_model", cfg.get("model", {})))
            # baselines are trained with the same trainer; distillation has no effect unless risk paths exist.
            bcfg = {k: (v.copy() if isinstance(v, dict) else v) for k, v in cfg.items()}
            bcfg["training"] = dict(cfg.get("training", {}))
            bcfg["training"]["loss_weights"] = dict(cfg.get("training", {}).get("loss_weights", {}))
            if model_name.lower() != "ucmr-net":
                bcfg["training"]["loss_weights"]["distill"] = 0.0
                for ph in bcfg["training"].get("phases", []):
                    ph["distill"] = 0.0
            res = train_one_seed(model, loaders, bcfg, device, output_dir=str(Path(args.output_dir) / model_name.replace("/", "_")), seed=seed)
            results[model_name][str(seed)] = res["metrics"]
    save_json(results, Path(args.output_dir) / "unified_baseline_metrics.json")


if __name__ == "__main__":
    main()
