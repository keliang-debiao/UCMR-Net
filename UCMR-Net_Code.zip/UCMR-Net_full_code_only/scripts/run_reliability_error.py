from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

import _bootstrap  # noqa: F401
from ucmr_net.data.factory import build_loaders
from ucmr_net.models.ucmr_net import build_ucmr_from_stats
from ucmr_net.training.trainer import evaluate
from ucmr_net.utils.metrics import pearson_corr, spearman_corr
from ucmr_net.utils.config import load_config, save_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    loaders, stats = build_loaders(args.data, cfg.get("training", {}).get("batch_size", 32), 0)
    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("runtime", {}).get("use_cuda", True) else "cpu")
    model = build_ucmr_from_stats(stats, cfg.get("model", {})).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt.get("state_dict", ckpt))
    res = evaluate(model, loaders["test"], device)
    abs_err = np.abs(res["labels"] - res["predictions"])
    risk = res["risk_scores"]
    if risk is None:
        raise RuntimeError("Model did not return residual reliability-risk scores.")
    risk_mean = risk.mean(axis=1)
    qs = np.quantile(risk_mean, [0, .25, .5, .75, 1])
    quartile_mae = []
    for i in range(4):
        idx = (risk_mean >= qs[i]) & (risk_mean <= qs[i+1] if i == 3 else risk_mean < qs[i+1])
        quartile_mae.append(float(abs_err[idx].mean()))
    high = abs_err >= np.quantile(abs_err, 0.75)
    order = np.argsort(risk_mean)
    ranks = np.argsort(order)
    # Mann-Whitney style AUROC for high-error detection
    pos = ranks[high]
    n_pos = max(high.sum(), 1)
    n_neg = max((~high).sum(), 1)
    auc = (pos.sum() - n_pos * (n_pos - 1) / 2) / (n_pos * n_neg)
    save_json({
        "pearson_risk_abs_error": pearson_corr(risk_mean, abs_err),
        "spearman_risk_abs_error": spearman_corr(risk_mean, abs_err),
        "quartile_mae": quartile_mae,
        "high_error_auroc": float(auc),
    }, Path(args.output_dir) / "reliability_error_metrics.json")


if __name__ == "__main__":
    main()
