from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


def mae(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true).reshape(-1), np.asarray(y_pred).reshape(-1)
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true).reshape(-1), np.asarray(y_pred).reshape(-1)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def pearson_corr(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true).reshape(-1), np.asarray(y_pred).reshape(-1)
    if np.std(y_true) < 1e-12 or np.std(y_pred) < 1e-12:
        return 0.0
    return float(np.corrcoef(y_true, y_pred)[0, 1])


def non0_binary_metrics(y_true, y_score) -> Dict[str, float]:
    y_true = np.asarray(y_true).reshape(-1)
    y_score = np.asarray(y_score).reshape(-1)
    mask = y_true != 0
    yt = (y_true[mask] > 0).astype(int)
    yp = (y_score[mask] > 0).astype(int)
    if len(yt) == 0:
        return {"acc2": float("nan"), "f1": float("nan"), "non0_n": 0}
    acc = float(np.mean(yt == yp))
    tp = np.sum((yt == 1) & (yp == 1))
    fp = np.sum((yt == 0) & (yp == 1))
    fn = np.sum((yt == 1) & (yp == 0))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    return {"acc2": float(acc * 100), "f1": float(f1 * 100), "non0_n": int(len(yt))}


def regression_metrics(y_true, y_pred) -> Dict[str, float]:
    return {"mae": mae(y_true, y_pred), "rmse": rmse(y_true, y_pred), "corr": pearson_corr(y_true, y_pred)}


def all_metrics(y_true, y_pred) -> Dict[str, float]:
    out = regression_metrics(y_true, y_pred)
    out.update(non0_binary_metrics(y_true, y_pred))
    return out


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def calibration_metrics(y_true, logits, n_bins: int = 15) -> Dict[str, float]:
    y_true = np.asarray(y_true).reshape(-1)
    logits = np.asarray(logits).reshape(-1)
    mask = y_true != 0
    y = (y_true[mask] > 0).astype(float)
    p = sigmoid(logits[mask])
    if len(y) == 0:
        return {"ece": float("nan"), "mce": float("nan"), "brier": float("nan"), "nll": float("nan")}
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    mce = 0.0
    for lo, hi in zip(bins[:-1], bins[1:]):
        idx = (p >= lo) & (p < hi if hi < 1.0 else p <= hi)
        if idx.any():
            conf = np.mean(p[idx])
            acc = np.mean((p[idx] >= 0.5) == y[idx])
            gap = abs(conf - acc)
            ece += gap * np.mean(idx)
            mce = max(mce, gap)
    brier = float(np.mean((p - y) ** 2))
    eps = 1e-8
    nll = float(-np.mean(y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps)))
    return {"ece": float(ece), "mce": float(mce), "brier": brier, "nll": nll}


def confidence_bins(y_true, logits, n_bins: int = 15) -> Dict[str, list]:
    y_true = np.asarray(y_true).reshape(-1)
    logits = np.asarray(logits).reshape(-1)
    mask = y_true != 0
    y = (y_true[mask] > 0).astype(float)
    p = sigmoid(logits[mask])
    rows = []
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    for lo, hi in zip(bins[:-1], bins[1:]):
        idx = (p >= lo) & (p < hi if hi < 1.0 else p <= hi)
        if idx.any():
            rows.append({"bin_low": float(lo), "bin_high": float(hi), "count": int(idx.sum()), "confidence": float(np.mean(p[idx])), "accuracy": float(np.mean((p[idx] >= 0.5) == y[idx]))})
    return {"bins": rows}


def spearman_corr(x, y) -> float:
    x = np.asarray(x).reshape(-1)
    y = np.asarray(y).reshape(-1)
    rx = np.argsort(np.argsort(x))
    ry = np.argsort(np.argsort(y))
    return pearson_corr(rx, ry)
