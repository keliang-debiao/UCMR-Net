from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, Optional

import numpy as np
import torch
from torch import nn

try:
    torch.set_num_threads(1)
except Exception:
    pass

from ucmr_net.data.multimodal_dataset import make_masked_batch, random_modality_mask
from ucmr_net.training.losses import multitask_loss
from ucmr_net.utils.metrics import all_metrics, calibration_metrics


def set_seed(seed: int) -> None:
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def to_device(batch: Dict[str, torch.Tensor], device: torch.device) -> Dict[str, torch.Tensor]:
    return {k: v.to(device) if torch.is_tensor(v) else v for k, v in batch.items()}


def make_optimizer(model: nn.Module, cfg: Dict, phase: int = 1):
    weight_decay = float(cfg.get("weight_decay", 1e-4))
    lr = float(cfg.get("lr", 1e-3))
    bert_lr = float(cfg.get("bert_lr", 2e-5))
    non_text_lr = float(cfg.get("non_text_lr", lr))
    if any("bert" in n.lower() for n, _ in model.named_parameters()):
        bert_params = [p for n, p in model.named_parameters() if "bert" in n.lower() and p.requires_grad]
        other_params = [p for n, p in model.named_parameters() if "bert" not in n.lower() and p.requires_grad]
        groups = []
        if bert_params:
            groups.append({"params": bert_params, "lr": bert_lr})
        if other_params:
            groups.append({"params": other_params, "lr": non_text_lr})
        return torch.optim.AdamW(groups, weight_decay=weight_decay)
    return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=weight_decay)


def evaluate(model: nn.Module, loader, device: torch.device, mask: Optional[torch.Tensor] = None) -> Dict[str, object]:
    model.eval()
    y_true, y_pred, logits, risk = [], [], [], []
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, device)
            if mask is not None:
                batch = make_masked_batch(batch, mask.repeat(batch["label"].shape[0], 1))
            out = model(batch)
            y_true.append(batch["label"].detach().cpu().numpy())
            y_pred.append(out["regression"].detach().cpu().numpy())
            logits.append(out["binary_logit"].detach().cpu().numpy())
            if "risk_audio" in out and "risk_visual" in out:
                risk.append(torch.cat([out["risk_audio"], out["risk_visual"]], dim=-1).detach().cpu().numpy())
    y_true = np.concatenate(y_true)
    y_pred = np.concatenate(y_pred)
    logits = np.concatenate(logits)
    out_metrics = all_metrics(y_true, y_pred)
    out_metrics.update({f"cal_{k}": v for k, v in calibration_metrics(y_true, logits).items()})
    return {
        "metrics": out_metrics,
        "labels": y_true,
        "predictions": y_pred,
        "binary_logits": logits,
        "risk_scores": np.concatenate(risk) if risk else None,
    }


def train_one_seed(model: nn.Module, loaders: Dict, cfg: Dict, device: torch.device, output_dir: Optional[str] = None, seed: int = 0) -> Dict[str, object]:
    set_seed(seed)
    model.to(device)
    train_cfg = cfg.get("training", cfg)
    loss_weights = train_cfg.get("loss_weights", {})
    patience = int(train_cfg.get("early_stopping_patience", 8))
    best_val = float("inf")
    best_state = None
    wait = 0

    phase_settings = train_cfg.get("phases")
    if not phase_settings:
        phase_settings = [
            {"epochs": int(train_cfg.get("epochs", 50)), "missing_rate": float(train_cfg.get("missing_rate", 0.1)), "distill": float(loss_weights.get("distill", 0.05))}
        ]

    for phase_idx, phase in enumerate(phase_settings, start=1):
        # Optional BERT freezing hook. Works if a model exposes BERT-named params.
        if phase.get("freeze_bert", False):
            for name, p in model.named_parameters():
                if "bert" in name.lower():
                    p.requires_grad = False
        if phase.get("unfreeze_bert", False):
            for name, p in model.named_parameters():
                if "bert" in name.lower():
                    p.requires_grad = True
        opt = make_optimizer(model, train_cfg, phase_idx)
        missing_rate = float(phase.get("missing_rate", train_cfg.get("missing_rate", 0.1)))
        phase_loss_weights = dict(loss_weights)
        phase_loss_weights["distill"] = float(phase.get("distill", phase_loss_weights.get("distill", 0.05)))
        for _ in range(int(phase.get("epochs", 1))):
            model.train()
            for batch in loaders["train"]:
                batch = to_device(batch, device)
                y = batch["label"]
                full_out = model(batch)
                mask = random_modality_mask(y.shape[0], missing_rate, device)
                masked_batch = make_masked_batch(batch, mask)
                masked_out = model(masked_batch)
                loss_full = multitask_loss(full_out, y, {**phase_loss_weights, "distill": 0.0})
                loss_masked = multitask_loss(masked_out, y, phase_loss_weights, teacher_regression=full_out["regression"])
                loss = loss_full + loss_masked
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(train_cfg.get("grad_clip", 1.0)))
                opt.step()
            val = evaluate(model, loaders["val"], device)["metrics"]
            if val["mae"] < best_val:
                best_val = val["mae"]
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                wait = 0
            else:
                wait += 1
                if wait >= patience:
                    break
    if best_state is not None:
        model.load_state_dict(best_state)
    result = evaluate(model, loaders["test"], device)
    if output_dir:
        outdir = Path(output_dir)
        outdir.mkdir(parents=True, exist_ok=True)
        torch.save({"state_dict": model.state_dict(), "seed": seed, "val_mae": best_val}, outdir / f"ucmr_seed{seed}.pt")
        np.savez_compressed(outdir / f"predictions_seed{seed}.npz", labels=result["labels"], predictions=result["predictions"], binary_logits=result["binary_logits"], risk_scores=result["risk_scores"])
    return result
