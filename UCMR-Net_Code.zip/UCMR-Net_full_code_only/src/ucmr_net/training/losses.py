from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn.functional as F


def pearson_loss(y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
    yp = y_pred - y_pred.mean()
    yt = y_true - y_true.mean()
    r = (yp * yt).sum() / (torch.sqrt((yp ** 2).sum() + 1e-8) * torch.sqrt((yt ** 2).sum() + 1e-8))
    return 1.0 - r


def ccc_loss(y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
    mean_p = y_pred.mean()
    mean_t = y_true.mean()
    var_p = y_pred.var(unbiased=False)
    var_t = y_true.var(unbiased=False)
    cov = ((y_pred - mean_p) * (y_true - mean_t)).mean()
    ccc = 2 * cov / (var_p + var_t + (mean_p - mean_t) ** 2 + 1e-8)
    return 1.0 - ccc


def ordinal_targets(y: torch.Tensor, classes: int = 7, low: float = -3.0, high: float = 3.0) -> torch.Tensor:
    y_clip = y.clamp(low, high)
    bins = torch.linspace(low, high, classes + 1, device=y.device)
    return torch.bucketize(y_clip, bins[1:-1]).long()


def multitask_loss(outputs: Dict[str, torch.Tensor], y: torch.Tensor, weights: Dict[str, float], teacher_regression: Optional[torch.Tensor] = None) -> torch.Tensor:
    reg = outputs["regression"]
    main = 0.25 * F.smooth_l1_loss(reg, y) + 0.25 * ccc_loss(reg, y) + 0.50 * pearson_loss(reg, y)
    mask_non0 = y != 0
    if mask_non0.any():
        binary_y = (y[mask_non0] > 0).float()
        bin_loss = F.binary_cross_entropy_with_logits(outputs["binary_logit"][mask_non0], binary_y)
    else:
        bin_loss = torch.zeros((), device=y.device)
    ord_y = ordinal_targets(y, classes=outputs["ordinal_logit"].shape[-1])
    ord_loss = F.cross_entropy(outputs["ordinal_logit"], ord_y)
    distill = torch.zeros((), device=y.device)
    if teacher_regression is not None:
        distill = F.mse_loss(outputs["regression"], teacher_regression.detach())
    return (
        float(weights.get("main", 1.0)) * main
        + float(weights.get("binary", 0.1)) * bin_loss
        + float(weights.get("ordinal", 0.1)) * ord_loss
        + float(weights.get("distill", 0.05)) * distill
    )
