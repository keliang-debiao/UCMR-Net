from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch
from torch import nn
import torch.nn.functional as F

from .components import SequenceEncoder, MLPHead, Projection


@dataclass
class UCMRConfig:
    text_dim: int
    audio_dim: int
    visual_dim: int
    hidden_dim: int = 128
    ordinal_classes: int = 7
    dropout: float = 0.30
    use_residual_fusion: bool = True
    use_adaptive_weighting: bool = True
    text_anchor_mode: str = "text"  # text, mean, none
    audio_is_sequence: bool = True
    visual_is_sequence: bool = True


class UCMRNet(nn.Module):
    """UCMR-Net: text-anchored residual fusion with adaptive residual weighting.

    This implementation treats the residual score as a learned reliability-risk/gating
    signal rather than as formal aleatoric or epistemic uncertainty.
    """

    def __init__(self, cfg: UCMRConfig):
        super().__init__()
        self.cfg = cfg
        h = cfg.hidden_dim
        self.text_proj = Projection(cfg.text_dim, h, cfg.dropout)
        self.audio_encoder = SequenceEncoder(cfg.audio_dim, h, cfg.dropout, use_lstm=cfg.audio_is_sequence)
        self.visual_encoder = SequenceEncoder(cfg.visual_dim, h, cfg.dropout, use_lstm=cfg.visual_is_sequence)
        self.audio_residual_proj = nn.Linear(h, h)
        self.visual_residual_proj = nn.Linear(h, h)
        self.residual_estimator = nn.Sequential(
            nn.Linear(h * 3, h),
            nn.LayerNorm(h),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(h, h),
        )
        self.reliability_audio = nn.Sequential(nn.Linear(h, h), nn.Tanh(), nn.Linear(h, 1), nn.Softplus())
        self.reliability_visual = nn.Sequential(nn.Linear(h, h), nn.Tanh(), nn.Linear(h, 1), nn.Softplus())
        self.regression_head = MLPHead(h, 1, cfg.dropout)
        self.binary_head = MLPHead(h, 1, cfg.dropout)
        self.ordinal_head = MLPHead(h, cfg.ordinal_classes, cfg.dropout)

    def encode(self, text: torch.Tensor, audio: torch.Tensor, visual: torch.Tensor) -> Dict[str, torch.Tensor]:
        h_t = self.text_proj(text)
        h_a = self.audio_encoder(audio)
        h_v = self.visual_encoder(visual)
        return {"text": h_t, "audio": h_a, "visual": h_v}

    def fuse(self, enc: Dict[str, torch.Tensor], mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        h_t, h_a, h_v = enc["text"], enc["audio"], enc["visual"]
        if self.cfg.text_anchor_mode == "mean":
            anchor = (h_t + h_a + h_v) / 3.0
        elif self.cfg.text_anchor_mode == "none":
            anchor = torch.zeros_like(h_t)
        else:
            anchor = h_t

        if not self.cfg.use_residual_fusion:
            fused = anchor
            score_a = torch.zeros(anchor.size(0), 1, device=anchor.device)
            score_v = torch.zeros(anchor.size(0), 1, device=anchor.device)
            weights = torch.zeros(anchor.size(0), 2, device=anchor.device)
            return {"fused": fused, "risk_audio": score_a, "risk_visual": score_v, "residual_weights": weights}

        r_a = self.audio_residual_proj(h_a)
        r_v = self.visual_residual_proj(h_v)
        residual = self.residual_estimator(torch.cat([anchor, r_a, r_v], dim=-1))
        if self.cfg.use_adaptive_weighting:
            score_a = self.reliability_audio(r_a)
            score_v = self.reliability_visual(r_v)
            risk = torch.cat([score_a, score_v], dim=-1)
            weights = torch.softmax(-risk, dim=-1)
        else:
            score_a = torch.zeros(anchor.size(0), 1, device=anchor.device)
            score_v = torch.zeros(anchor.size(0), 1, device=anchor.device)
            weights = torch.full((anchor.size(0), 2), 0.5, device=anchor.device)
        if mask is not None:
            # nonverbal weights are set to zero when corresponding stream is unavailable
            weights = weights * mask[:, 1:3]
            denom = weights.sum(dim=1, keepdim=True).clamp_min(1e-6)
            weights = weights / denom
        residual_scale = weights.sum(dim=-1, keepdim=True)
        fused = anchor + residual_scale * residual
        return {"fused": fused, "risk_audio": score_a, "risk_visual": score_v, "residual_weights": weights}

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        enc = self.encode(batch["text"], batch["audio"], batch["visual"])
        fused_dict = self.fuse(enc, batch.get("mask"))
        h = fused_dict["fused"]
        reg = self.regression_head(h).squeeze(-1)
        binary_logit = self.binary_head(h).squeeze(-1)
        ordinal_logit = self.ordinal_head(h)
        return {
            "regression": reg,
            "binary_logit": binary_logit,
            "ordinal_logit": ordinal_logit,
            **fused_dict,
        }

    def variant(self, name: str) -> "UCMRNet":
        raise RuntimeError("Create ablation variants through the factory to ensure configs are explicit.")


def build_ucmr_from_stats(stats, model_cfg: Dict) -> UCMRNet:
    cfg = UCMRConfig(
        text_dim=stats.text_dim,
        audio_dim=stats.audio_dim,
        visual_dim=stats.visual_dim,
        hidden_dim=int(model_cfg.get("hidden_dim", 128)),
        ordinal_classes=int(model_cfg.get("ordinal_classes", 7)),
        dropout=float(model_cfg.get("dropout", 0.30)),
        use_residual_fusion=bool(model_cfg.get("use_residual_fusion", True)),
        use_adaptive_weighting=bool(model_cfg.get("use_adaptive_weighting", True)),
        text_anchor_mode=str(model_cfg.get("text_anchor_mode", "text")),
        audio_is_sequence=bool(getattr(stats, "audio_is_sequence", True)),
        visual_is_sequence=bool(getattr(stats, "visual_is_sequence", True)),
    )
    return UCMRNet(cfg)
