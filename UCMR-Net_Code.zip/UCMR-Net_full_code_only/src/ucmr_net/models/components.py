from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


class SequenceEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float = 0.3, use_lstm: bool = True):
        super().__init__()
        self.use_lstm = use_lstm
        if use_lstm:
            self.encoder = nn.LSTM(input_dim, hidden_dim // 2, batch_first=True, bidirectional=True)
            self.proj = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Dropout(dropout))
        else:
            self.encoder = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.GELU(), nn.Dropout(dropout))
            self.proj = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim == 2:
            if self.use_lstm:
                x = x.unsqueeze(1)
            else:
                return self.proj(self.encoder(x))
        if self.use_lstm:
            z, _ = self.encoder(x)
            return self.proj(z.mean(dim=1))
        return self.proj(self.encoder(x.mean(dim=1)))


class MLPHead(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, dropout: float = 0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.LayerNorm(input_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(input_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class Projection(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float = 0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim == 3:
            x = x.mean(dim=1)
        return self.net(x)
