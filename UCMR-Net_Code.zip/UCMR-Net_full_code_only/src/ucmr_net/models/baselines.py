from __future__ import annotations

from typing import Dict

import torch
from torch import nn
import torch.nn.functional as F

from .components import Projection, SequenceEncoder, MLPHead


class BasePredictionMixin:
    def _heads(self, h: torch.Tensor) -> Dict[str, torch.Tensor]:
        return {
            "regression": self.regression_head(h).squeeze(-1),
            "binary_logit": self.binary_head(h).squeeze(-1),
            "ordinal_logit": self.ordinal_head(h),
        }


class BERTOnlyBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, hidden_dim: int = 128, ordinal_classes: int = 7, dropout: float = 0.3):
        super().__init__()
        self.text_proj = Projection(text_dim, hidden_dim, dropout)
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        return self._heads(self.text_proj(batch["text"]))


class EarlyFusionBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 128, ordinal_classes: int = 7, dropout: float = 0.3):
        super().__init__()
        self.proj = Projection(text_dim + audio_dim + visual_dim, hidden_dim, dropout)
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        text = batch["text"].mean(dim=1) if batch["text"].ndim == 3 else batch["text"]
        audio = batch["audio"].mean(dim=1) if batch["audio"].ndim == 3 else batch["audio"]
        visual = batch["visual"].mean(dim=1) if batch["visual"].ndim == 3 else batch["visual"]
        h = self.proj(torch.cat([text, audio, visual], dim=-1))
        return self._heads(h)


class LateFusionBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 128, ordinal_classes: int = 7, dropout: float = 0.3, audio_is_sequence: bool = True, visual_is_sequence: bool = True):
        super().__init__()
        self.text_proj = Projection(text_dim, hidden_dim, dropout)
        self.audio_encoder = SequenceEncoder(audio_dim, hidden_dim, dropout, use_lstm=audio_is_sequence)
        self.visual_encoder = SequenceEncoder(visual_dim, hidden_dim, dropout, use_lstm=visual_is_sequence)
        self.fuser = Projection(hidden_dim * 3, hidden_dim, dropout)
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        h = self.fuser(torch.cat([self.text_proj(batch["text"]), self.audio_encoder(batch["audio"]), self.visual_encoder(batch["visual"])], dim=-1))
        return self._heads(h)


class TensorFusionBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 64, ordinal_classes: int = 7, dropout: float = 0.3, audio_is_sequence: bool = True, visual_is_sequence: bool = True):
        super().__init__()
        self.text_proj = Projection(text_dim, hidden_dim, dropout)
        self.audio_encoder = SequenceEncoder(audio_dim, hidden_dim, dropout, use_lstm=audio_is_sequence)
        self.visual_encoder = SequenceEncoder(visual_dim, hidden_dim, dropout, use_lstm=visual_is_sequence)
        self.fuser = Projection(hidden_dim * 6, hidden_dim * 2, dropout)
        self.regression_head = MLPHead(hidden_dim * 2, 1, dropout)
        self.binary_head = MLPHead(hidden_dim * 2, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim * 2, ordinal_classes, dropout)

    def forward(self, batch):
        t = self.text_proj(batch["text"])
        a = self.audio_encoder(batch["audio"])
        v = self.visual_encoder(batch["visual"])
        ta = t * a
        tv = t * v
        av = a * v
        tav = t * a * v
        h = self.fuser(torch.cat([t, a, v, ta, tv, av + tav], dim=-1))
        return self._heads(h)


class LowRankFusionBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 128, rank: int = 16, ordinal_classes: int = 7, dropout: float = 0.3, audio_is_sequence: bool = True, visual_is_sequence: bool = True):
        super().__init__()
        self.text_proj = Projection(text_dim, rank, dropout)
        self.audio_encoder = SequenceEncoder(audio_dim, rank, dropout, use_lstm=audio_is_sequence)
        self.visual_encoder = SequenceEncoder(visual_dim, rank, dropout, use_lstm=visual_is_sequence)
        self.fuser = Projection(rank, hidden_dim, dropout)
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        h = self.text_proj(batch["text"]) * self.audio_encoder(batch["audio"]) * self.visual_encoder(batch["visual"])
        return self._heads(self.fuser(h))


class CrossModalAttentionBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 128, ordinal_classes: int = 7, dropout: float = 0.3, audio_is_sequence: bool = True, visual_is_sequence: bool = True):
        super().__init__()
        self.text_proj = Projection(text_dim, hidden_dim, dropout)
        self.audio_encoder = SequenceEncoder(audio_dim, hidden_dim, dropout, use_lstm=audio_is_sequence)
        self.visual_encoder = SequenceEncoder(visual_dim, hidden_dim, dropout, use_lstm=visual_is_sequence)
        self.attn = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True, dropout=dropout)
        self.fuser = Projection(hidden_dim * 3, hidden_dim, dropout)
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        x = torch.stack([self.text_proj(batch["text"]), self.audio_encoder(batch["audio"]), self.visual_encoder(batch["visual"])], dim=1)
        z, _ = self.attn(x, x, x)
        h = self.fuser(z.reshape(z.size(0), -1))
        return self._heads(h)


class MISABaseline(LateFusionBaseline):
    pass


class MAGBERTBaseline(nn.Module, BasePredictionMixin):
    def __init__(self, text_dim: int, audio_dim: int, visual_dim: int, hidden_dim: int = 128, ordinal_classes: int = 7, dropout: float = 0.3, audio_is_sequence: bool = True, visual_is_sequence: bool = True):
        super().__init__()
        self.text_proj = Projection(text_dim, hidden_dim, dropout)
        self.audio_encoder = SequenceEncoder(audio_dim, hidden_dim, dropout, use_lstm=audio_is_sequence)
        self.visual_encoder = SequenceEncoder(visual_dim, hidden_dim, dropout, use_lstm=visual_is_sequence)
        self.gate = nn.Sequential(nn.Linear(hidden_dim * 3, hidden_dim), nn.Sigmoid())
        self.regression_head = MLPHead(hidden_dim, 1, dropout)
        self.binary_head = MLPHead(hidden_dim, 1, dropout)
        self.ordinal_head = MLPHead(hidden_dim, ordinal_classes, dropout)

    def forward(self, batch):
        t = self.text_proj(batch["text"])
        a = self.audio_encoder(batch["audio"])
        v = self.visual_encoder(batch["visual"])
        g = self.gate(torch.cat([t, a, v], dim=-1))
        h = t + g * (a + v)
        return self._heads(h)


class MissingAwareBaseline(LateFusionBaseline):
    def forward(self, batch):
        out = super().forward(batch)
        return out


class LanguageDominantBaseline(MAGBERTBaseline):
    def forward(self, batch):
        t = self.text_proj(batch["text"])
        a = self.audio_encoder(batch["audio"])
        v = self.visual_encoder(batch["visual"])
        g = 0.35 * self.gate(torch.cat([t, a, v], dim=-1))
        h = t + g * (a + v)
        return self._heads(h)


def build_baseline(name: str, stats, cfg: Dict):
    name_l = name.lower()
    h = int(cfg.get("hidden_dim", 128))
    ordinal = int(cfg.get("ordinal_classes", 7))
    dropout = float(cfg.get("dropout", 0.3))
    kwargs = dict(text_dim=stats.text_dim, audio_dim=stats.audio_dim, visual_dim=stats.visual_dim, hidden_dim=h, ordinal_classes=ordinal, dropout=dropout)
    seq_kwargs = dict(audio_is_sequence=getattr(stats, "audio_is_sequence", True), visual_is_sequence=getattr(stats, "visual_is_sequence", True))
    if name_l in {"bert-only", "bertonly", "text-only"}:
        return BERTOnlyBaseline(stats.text_dim, h, ordinal, dropout)
    if name_l in {"ef-lstm", "earlyfusion", "early-fusion"}:
        return EarlyFusionBaseline(**kwargs)
    if name_l in {"lf-lstm", "latefusion", "late-fusion"}:
        return LateFusionBaseline(**kwargs, **seq_kwargs)
    if name_l == "tfn":
        return TensorFusionBaseline(**kwargs, **seq_kwargs)
    if name_l == "lmf":
        return LowRankFusionBaseline(**kwargs, rank=int(cfg.get("rank", 16)), **seq_kwargs)
    if name_l == "mult":
        return CrossModalAttentionBaseline(**kwargs, **seq_kwargs)
    if name_l == "misa":
        return MISABaseline(**kwargs, **seq_kwargs)
    if name_l in {"mag-bert", "magbert"}:
        return MAGBERTBaseline(**kwargs, **seq_kwargs)
    if name_l in {"tfr-net", "tfrnet", "missmodal", "umdf", "corrkd"}:
        return MissingAwareBaseline(**kwargs, **seq_kwargs)
    if name_l == "lnln":
        return LanguageDominantBaseline(**kwargs, **seq_kwargs)
    raise ValueError(f"Unknown baseline: {name}")
