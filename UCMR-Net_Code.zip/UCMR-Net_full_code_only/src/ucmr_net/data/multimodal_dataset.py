from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset


_SPLIT_ALIASES = {
    "train": ("train", "tr", "training"),
    "val": ("val", "valid", "validation", "dev"),
    "test": ("test", "te", "testing"),
}
_MODALITY_ALIASES = {
    "text": ("text", "txt", "language", "words", "bert", "text_features"),
    "audio": ("audio", "acoustic", "covarep", "a"),
    "visual": ("visual", "vision", "facet", "v"),
    "labels": ("labels", "label", "y", "sentiment", "target", "targets"),
}


def _as_float_tensor(x: np.ndarray) -> torch.Tensor:
    x = np.asarray(x)
    if x.dtype.kind in {"U", "S", "O"}:
        raise TypeError("String/token arrays are not supported by this numeric loader. Provide precomputed BERT text_features or implement a token loader.")
    return torch.tensor(x, dtype=torch.float32)


def _try_keys(npz: Dict[str, np.ndarray], split: str, modality: str) -> Optional[np.ndarray]:
    split_aliases = _SPLIT_ALIASES[split]
    mod_aliases = _MODALITY_ALIASES[modality]
    candidates = []
    for s in split_aliases:
        for m in mod_aliases:
            candidates.extend([
                f"{s}_{m}", f"{m}_{s}", f"{s}/{m}", f"{m}/{s}",
                f"X_{m}_{s}", f"{s}_X_{m}", f"{s}{m}", f"{m}{s}",
            ])
    if modality == "labels":
        candidates += [f"y_{split}", f"{split}_y", f"label_{split}", f"{split}_label"]
    for k in candidates:
        if k in npz:
            return npz[k]
    return None


def _mean_pool_if_sequence(x: torch.Tensor) -> torch.Tensor:
    if x.ndim == 3:
        return x.mean(dim=1)
    return x


@dataclass
class ModalityStats:
    text_dim: int
    audio_dim: int
    visual_dim: int
    audio_is_sequence: bool
    visual_is_sequence: bool


class MultimodalNPZDataset(Dataset):
    """Generic CMU-MOSI/CMU-MOSEI-style numeric feature loader.

    Expected NPZ keys may use either split-first or modality-first naming, such as:
    train_text, train_audio, train_visual, train_y
    text_train, audio_train, visual_train, y_train

    Text should be precomputed contextual features by default. Audio and visual may be
    either vectors (N, D) or temporal sequences (N, T, D).
    """

    def __init__(self, npz_path: str | Path, split: str = "train") -> None:
        self.path = Path(npz_path)
        if not self.path.exists():
            raise FileNotFoundError(f"NPZ file not found: {self.path}")
        data = dict(np.load(self.path, allow_pickle=True))
        self.text = _as_float_tensor(_try_keys(data, split, "text"))
        self.audio = _as_float_tensor(_try_keys(data, split, "audio"))
        self.visual = _as_float_tensor(_try_keys(data, split, "visual"))
        y = _try_keys(data, split, "labels")
        if y is None:
            raise KeyError(f"Cannot find labels for split={split} in {self.path}")
        self.y = torch.tensor(np.asarray(y).reshape(-1), dtype=torch.float32)
        n = len(self.y)
        if not (len(self.text) == len(self.audio) == len(self.visual) == n):
            raise ValueError("Text, audio, visual, and labels must have identical first dimension.")

    @property
    def stats(self) -> ModalityStats:
        text = _mean_pool_if_sequence(self.text)
        audio = self.audio
        visual = self.visual
        return ModalityStats(
            text_dim=int(text.shape[-1]),
            audio_dim=int(audio.shape[-1]),
            visual_dim=int(visual.shape[-1]),
            audio_is_sequence=audio.ndim == 3,
            visual_is_sequence=visual.ndim == 3,
        )

    def __len__(self) -> int:
        return len(self.y)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return {
            "text": self.text[idx],
            "audio": self.audio[idx],
            "visual": self.visual[idx],
            "label": self.y[idx],
            "mask": torch.ones(3, dtype=torch.float32),
        }


def make_masked_batch(batch: Dict[str, torch.Tensor], mask: torch.Tensor) -> Dict[str, torch.Tensor]:
    """Apply modality availability mask [T, A, V] to a batch."""
    out = dict(batch)
    if mask.ndim == 1:
        mask = mask.to(batch["label"].device).view(1, 3)
    else:
        mask = mask.to(batch["label"].device)
    out["text"] = batch["text"] * mask[:, 0].view(-1, *([1] * (batch["text"].ndim - 1)))
    out["audio"] = batch["audio"] * mask[:, 1].view(-1, *([1] * (batch["audio"].ndim - 1)))
    out["visual"] = batch["visual"] * mask[:, 2].view(-1, *([1] * (batch["visual"].ndim - 1)))
    out["mask"] = mask
    return out


def random_modality_mask(batch_size: int, missing_rate: float, device: torch.device, keep_text_probability: float = 0.85) -> torch.Tensor:
    """Sample masks for counterfactual masked-modality training.

    Text is kept more often because the model is text-anchored. At least one modality
    remains available for every sample.
    """
    mask = torch.ones(batch_size, 3, device=device)
    drop = torch.rand(batch_size, 3, device=device) < missing_rate
    text_keep = torch.rand(batch_size, device=device) < keep_text_probability
    drop[:, 0] = drop[:, 0] & (~text_keep)
    mask[drop] = 0.0
    empty = mask.sum(dim=1) == 0
    if empty.any():
        mask[empty, 0] = 1.0
    return mask
