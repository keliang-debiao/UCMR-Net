from __future__ import annotations

from pathlib import Path
from typing import Tuple

from torch.utils.data import DataLoader

from .multimodal_dataset import MultimodalNPZDataset


def build_loaders(npz_path: str, batch_size: int, num_workers: int = 0):
    train = MultimodalNPZDataset(npz_path, "train")
    val = MultimodalNPZDataset(npz_path, "val")
    test = MultimodalNPZDataset(npz_path, "test")
    loaders = {
        "train": DataLoader(train, batch_size=batch_size, shuffle=True, num_workers=num_workers),
        "val": DataLoader(val, batch_size=batch_size, shuffle=False, num_workers=num_workers),
        "test": DataLoader(test, batch_size=batch_size, shuffle=False, num_workers=num_workers),
    }
    return loaders, train.stats
